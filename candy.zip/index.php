<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Favorite Candy</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </nav>
  </header>
  <main>
    <section>
      <h1>My Favorite Candy is Snickers</h1>
      <article>
        <h2>About the Candy</h2>
        <p>The very first SNICKERS Bar, allegedly named after a horse, was manufactured in Chicago and sold for five cents.SNICKERS is called the Marathon Bar in the UK. Fun Size SNICKERS is created, followed by an increase in satisfaction levels worldwide. SNICKERS is an official sponsor of the 1984 LA Olympic Games. We take home gold in every non-sport event. The SNICKERS Ice Cream Bar is introduced. We are forever changed. The award-winning “You’re not you when you’re hungry” campaign is created and celebrated.SNICKERS passes $1 Billion in sales in the US.SNICKERS Brownie flavors are born. World peace is imminent.</p>
      </article>
      <article>
        <h2>Nutritional Information</h2>
        <p>With the nutritional profile you expect and taste you’ve always wanted, Snickers Hi-Protein staves off hunger without sacrificing flavor. Enjoy the same chocolate, caramel and peanut flavors you know and love from Snickers along with the protein and fiber your body needs to stay fully satisfied. Perfect to carry you between meals or after a great workout.</p>
      </article>
    </section>
    <aside>
    
    </aside>
  </main>
  <footer>
    <div class="logo">
      <img src="snk-banner-test-dsk (1).avif" alt="Company logo">
    </div>
    <div class="company-info">
      
    </div>
    <div class="contact-form">
      <h3>Contact Us</h3>
      <form>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name"><br><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email"><br><br>
        <label for="message">Message:</label>
        <textarea id="message" name="message"></textarea><br><br>
        <input type="submit" value="Submit">
      </form>

    </div>
  </footer>
</body>
</html>